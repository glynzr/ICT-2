#Tapsiriq 1
from random import randint
def selection(li):
    for i in range(len(li)-1):
        min_=i
        for j in range(i+1,len(li)):
            if li[min_]>li[j]:
                min_=j
        if min_!=i:
            li[min_],li[i]=li[i],li[min_]
    return li

def EBOB(a,b):
    if a==0 or b==0:
        return a+b
    if a<b:
        return EBOB(a,b-a)
    else:
        return EBOB(a-b,b)

while True:
    n=int(input("Listin uzunlugu: "))
    if n%2==0:
        break

A=[]# unsorted list

i=0
while i<n: #listin cut ededlerle doldurulmasi
    a=randint(1,20)
    if a%2==0:
        A+=[a]
        i+=1
print("Unsorted list->{}".format(A))
A=selection(A)#sorted list

print("Sorted list->{}".format(A))
B=[]#Ebob listi
for i in range(0,len(A)-1,2):
    B+=[EBOB(A[i],A[i+1])]

print("Ebob->{}".format(B))


