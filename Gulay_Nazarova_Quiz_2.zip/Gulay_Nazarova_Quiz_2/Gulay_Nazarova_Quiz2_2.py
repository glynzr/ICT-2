#Tapsiriq 2
from random import randint
def sum_(n):
    su=0
    for i in str(n):
        su+=int(i)
    return su

def isPrime(n):
    if n==1:
        return False
    elif n==2:
        return True
    else:
        for i in range(2,n):
            if n%i==0:
                return False
        return True

    
while True:
    N=int(input("Enter the length of the list: "))
    if N>0:
        break
li=[randint(20,50) for _ in range(N)]# list
A=[]#reqemleri cemi sade olan list
for i in li:
    if isPrime(sum_(i)):
        A+=[i]
print("List->{}".format(li))
print("Reqemleri cemi sade  olan list->{}".format(A))
