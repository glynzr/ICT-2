#Tapsiriq 3
from random import randint
while True:
    N=int(input("Matrisin olcusunu daxil edin:"))
    if N>0:
        break

#matrisin yaradilmasi
li=[]
for i in range(N):
    li+=[[randint(1,20) for _ in range(N)]]

#matrisin cap edilmesi(before)
print("Before:")
for i in range(N):
    for b in li[i]:
        print("{:2d}".format(b),end=" ")
    print()
    
for i in range(N):
    for j in range(N-i):
        if li[i][j]%2==0:
            li[i][j]=0
        else:
            li[i][j]=1
print("\n")
print("After:")
for i in range(N):
    for b in li[i]:
        print("{:2d}".format(b),end=" ")
    print()

