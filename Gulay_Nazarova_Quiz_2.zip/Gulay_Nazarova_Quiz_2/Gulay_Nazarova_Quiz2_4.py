#Tapsiriq 4
colordict = {
    'black' : {'digits': '0' , 'magnitude': 0 , 'tolerance': '' },
    'brown' : {'digits': '1' , 'magnitude': 1 , 'tolerance': '+/-1%'},
    'red' : {'digits': '2' , 'magnitude': 2 , 'tolerance': '+/-2%' },
    'orange' : {'digits': '3' , 'magnitude': 3 , 'tolerance': ''},
    'yellow' : {'digits': '4' , 'magnitude': 4 , 'tolerance': '' },
    'green' : {'digits': '5' , 'magnitude': 5 , 'tolerance': '+/-0.5%' },
    'blue' : {'digits': '6' , 'magnitude': 6 , 'tolerance': '+/-0.25%'},
    'violet' : {'digits': '7' , 'magnitude': 7 , 'tolerance': '+/-0.1%'},
    'gray' : {'digits': '8' , 'magnitude': 8 , 'tolerance': '+/-0.05%' },
    'white' : {'digits': '9' , 'magnitude': 9 , 'tolerance': '' },
    'gold' : {'digits': '' , 'magnitude': -1 , 'tolerance': '+/-5%'},
    'silver' : {'digits': '' , 'magnitude': -2 , 'tolerance': '+/-5%'}
    }

n=int(input("Renglerin sayini daxil edin(4 or 5)->"))
li=[]#rengler
for i in range(n):
    a=input("{}.".format(i+1))
    li+=[a]
s=""
if n==4:
    s+=str((int(colordict[li[0]]["digits"])*10+\
       int(colordict[li[1]]["digits"]))*(10**\
       int(colordict[li[2]]["magnitude"])))+\
       colordict[li[3]]["tolerance"]
       
else:
    s+=str((int(colordict[li[0]]["digits"])*100+\
       int(colordict[li[1]]["digits"])*10+\
       int(colordict[li[2]]["digits"]))*(10**\
       int(colordict[li[3]]["magnitude"])))+\
       colordict[li[4]]["tolerance"]
       
print("Kod->"+s) 

    
       
    
