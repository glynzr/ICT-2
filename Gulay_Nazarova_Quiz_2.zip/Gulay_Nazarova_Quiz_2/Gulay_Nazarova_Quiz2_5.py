#Tapsiriq 5
def define_(s):
    if s=="soyad":
        return 0
    elif s=="ad":
        return 1
    elif s=="yas":
        return 2
    elif s=="bal":
        return 3
    elif s=="yer":
        return 4


def bubble(li,n,nonreverse):
    if n!=2 and n!=3:
        for i in range(len(li)-1):
            for j in range(len(li)-2,i-1,-1):
                if li[j+1].split(",")[n]<li[j].split(",")[n]:
                    li[j+1],li[j]=li[j],li[j+1]
    else:
        for i in range(len(li)-1):
            for j in range(len(li)-2,i-1,-1):
                if int(li[j+1].split(",")[n])<int(li[j].split(",")[n]):
                    li[j+1],li[j]=li[j],li[j+1]
        
    return li if nonreverse else li[::-1]

A=[]
s=input("sortlamanin novu: ")
a=input("artan ve ya azalan sira: ")
if a=="artan":
    a=True
else:
    a=False
    
f=open("students.txt")
for i in f:
    if i!="soyad,ad,yas,bal,yer\n":
        A+=[i]
f.close()

A=bubble(A,define_(s),a)
with open("result.txt","w") as f:
    for i in A:
        f.write(i)





